import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import shiffman.box2d.*; 
import org.jbox2d.common.*; 
import org.jbox2d.dynamics.joints.*; 
import org.jbox2d.collision.shapes.*; 
import org.jbox2d.collision.shapes.Shape; 
import org.jbox2d.common.*; 
import org.jbox2d.dynamics.*; 
import org.jbox2d.dynamics.contacts.*; 
import controlP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class NailProblem extends PApplet {











static public float sep = 10;

Box2DProcessing box2d;
ControlP5 cp5;
int NailCount = 3;

Chain chain;

ArrayList<Nail> nails;

public void setup() {
  
  
  
  cp5 = new ControlP5(this);
  
  cp5.addSlider("NailCount").setPosition(600,30).setSize(175,30).setRange(1,6).setNumberOfTickMarks(6).setColorLabel(color(0));
  cp5.getController("NailCount").getCaptionLabel().align(ControlP5.RIGHT, ControlP5.BOTTOM_OUTSIDE).setPaddingX(0);
  
  box2d = new Box2DProcessing(this);
  box2d.createWorld();
  
  nails = new ArrayList();
  chain = new Chain();
  
  resetNails();
}

public void draw() {
  background(255);
  
  if (!mousePressed) {
    box2d.step();
  }
  
  for(Nail n: nails) {
    if (n!=null) {n.display();}
  }
  
  chain.display();
}

public void resetNails() {
  for (Nail n: nails) {
    if (n != null) {n.destroy();};
  }
  nails = new ArrayList();
  
  for (int i=0; i < NailCount; i++) {
    float sep = width/(NailCount+1);
    nails.add(new Nail((i+1)*sep,height/2));
  }
}

public void mousePressed() {
  resetNails();
  chain.createLink(100, true);
}

public void mouseDragged() {
  chain.createLink(0, false);
}

public void mouseReleased() {
  chain.createLink(100, false);
}

public void keyPressed() {
  deleteNail(keyCode-48);
}

public void deleteNail(int n) {
  if (1 <= n && n <= nails.size()) {
    Nail nail = nails.get(n-1);
    
    if (nail != null) {
      nail.destroy();
      nails.set(n-1, null);
    }
  }
}
class Chain {
  
  float sep = NailProblem.sep;
  
  ArrayList<Link> links;
  
  Chain() {
    
    links = new ArrayList();
    
  }
  
  public void display() {
    for (Link l: links) {
      l.display();
    }
  }
  
  public void addJoint(Link l1, Link l2) {
    DistanceJointDef djd = new DistanceJointDef();
    djd.bodyA = l1.body;
    djd.bodyB = l2.body;
    djd.length = box2d.scalarPixelsToWorld(sep);
    box2d.world.createJoint(djd);
  }
  
  public boolean checkDistance() {
    Vec2 pos = box2d.getBodyPixelCoord(links.get(links.size()-1).body);
    return Math.pow(mouseX-pos.x,2) + Math.pow(mouseY-pos.y,2) >= Math.pow(sep,2);
  }
  
  public void createLink(float den, boolean resetList) {
    if (resetList) {
      links = new ArrayList();
    }
    
    if (den < 5 && !checkDistance()) {
      return;
    }
    
    links.add(new Link(mouseX, mouseY, sep/2, den));
    if (links.size() > 1) {
      addJoint(links.get(links.size()-2), links.get(links.size()-1));
    }
  }
    
}
class Link {
  
  Body body;
  float r;
  
  Link(float x, float y, float r, float density) {
    this.r = r;
    
    BodyDef bd = new BodyDef();
    bd.type = BodyType.DYNAMIC;
    
    bd.position = box2d.coordPixelsToWorld(x,y);
    body = box2d.world.createBody(bd);
    
    CircleShape cs = new CircleShape();
    cs.m_radius = box2d.scalarPixelsToWorld(r);
    
    FixtureDef fd = new FixtureDef();
    fd.shape = cs;
    fd.density = density;
    fd.filter.groupIndex = -1;
    
    body.createFixture(fd);
    
    
  }
  
  public void display() {
    Vec2 pos = box2d.getBodyPixelCoord(body);
    float a = body.getAngle();
    pushMatrix();
    translate(pos.x,pos.y);
    rotate(a);
    fill(color(175));
    stroke(0);
    strokeWeight(1);
    ellipse(0,0,r*2,r*2);
    popMatrix();
  }
  
  
}
class Nail {
  
  Body body;
  float r = 20;
  
  Nail (float x, float y) {
    
    BodyDef bd = new BodyDef();
    bd.type = BodyType.STATIC;
    
    bd.position = box2d.coordPixelsToWorld(x,y);
    body = box2d.world.createBody(bd);
    
    CircleShape cs = new CircleShape();
    cs.m_radius = box2d.scalarPixelsToWorld(r);
    
    FixtureDef fd = new FixtureDef();
    fd.shape = cs;
    
    body.createFixture(fd);
    
  }
  
  public void display() {
    Vec2 pos = box2d.getBodyPixelCoord(body);
    
    pushMatrix();
    translate(pos.x,pos.y);
    fill(0);
    stroke(0);
    ellipse(0, 0, 1.5f*r, 1.5f*r);
    popMatrix();
    
  }
  
  public void destroy() {
    box2d.destroyBody(body);
  } 
  
}
  public void settings() {  size(800,500);  smooth(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "NailProblem" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
